import 'package:flutter/material.dart';

const red = Color(0xffff0904);
const blue = Color(0xff0087f5);
const blue_dark = Color(0xff005ea4);
const circle = Color(0xffd9fc00);
const circle_regresive = Color(0xff3b3d42);
const estrella_color = Color(0xfffeb536);
const background_color = Color(0xffe2e2e2);